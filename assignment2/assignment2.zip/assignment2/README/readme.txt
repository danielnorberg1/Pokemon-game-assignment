Task 1-3 Responsible Daniel, input from Edvin och Erik.
Task 4-5 Responsible Edvin, input from Daniel och Erik.
Task 6-7 Responsible Erik, input from Edvin och Daniel.
Task 8 Responsible Edvin, We worked on it together and tried diffirent soulutions. 
Task 9 Everyone made sure their code was cohesive, Edvin was Responsible for the Enums with input from Erik and Daniel. 

After the code was done we all went through and explained our code so we all understand how the program works.