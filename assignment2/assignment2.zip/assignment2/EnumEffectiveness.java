package assignment2;

public enum EnumEffectiveness {
    SUPEREFFECTIVE,
    NOTEFFECTIVE,
    NORMALEFFECTIVE;
}
