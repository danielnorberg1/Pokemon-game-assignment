 package assignment2;
public class PokemonGame {
    public static void main(String[] args){

    }

}
